class User{
  String username;
  String password;
  int role;
  String bio;
  User(this.username, this.password,this.role, this.bio);
}

