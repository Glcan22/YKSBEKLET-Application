package com.example.girisapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
